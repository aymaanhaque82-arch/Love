import React, { useState, useEffect } from 'react';
import { Sparkles, Heart, Gift, Mail, Camera, Stars, ArrowUp, Music } from 'lucide-react';
import { SparkleCanvas } from './components/SparkleCanvas';
import { Navbar } from './components/Navbar';
import { AdmirationHero } from './components/AdmirationHero';
import { BouquetBuilder } from './components/BouquetBuilder';
import { DailyNotes } from './components/DailyNotes';
import { PhotoGallery } from './components/PhotoGallery';
import { CoupleSettingsModal } from './components/CoupleSettingsModal';
import { HelloKittyIcon } from './components/HelloKittyIcon';
import { BouquetGift, CoupleProfile, DailyNote, MemoryPhoto } from './types';
import { INITIAL_BOUQUETS, INITIAL_COUPLE, INITIAL_DAILY_NOTES, INITIAL_MEMORIES } from './utils/data';
import { playSound, startAmbientMusic, stopAmbientMusic } from './utils/audio';

export default function App() {
  const [activeTab, setActiveTab] = useState<'admiration' | 'bouquet' | 'notes' | 'gallery'>('admiration');
  const [profile, setProfile] = useState<CoupleProfile>(() => {
    const saved = localStorage.getItem('hk_love_profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_COUPLE;
      }
    }
    return INITIAL_COUPLE;
  });

  const [bouquets, setBouquets] = useState<BouquetGift[]>(() => {
    const saved = localStorage.getItem('hk_love_bouquets');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_BOUQUETS;
      }
    }
    return INITIAL_BOUQUETS;
  });

  const [notes, setNotes] = useState<DailyNote[]>(() => {
    const saved = localStorage.getItem('hk_love_notes');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_DAILY_NOTES;
      }
    }
    return INITIAL_DAILY_NOTES;
  });

  const [memories, setMemories] = useState<MemoryPhoto[]>(() => {
    const saved = localStorage.getItem('hk_love_memories');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_MEMORIES;
      }
    }
    return INITIAL_MEMORIES;
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [showBackToTop, setShowBackToTop] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('hk_love_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('hk_love_bouquets', JSON.stringify(bouquets));
  }, [bouquets]);

  useEffect(() => {
    localStorage.setItem('hk_love_notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('hk_love_memories', JSON.stringify(memories));
  }, [memories]);

  // Handle scroll listener for back-to-top
  useEffect(() => {
    const handleScroll = () => {
      setShowBackToTop(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleToggleSound = () => {
    setProfile((prev) => {
      const next = !prev.soundEnabled;
      if (next) playSound('pop', true);
      return { ...prev, soundEnabled: next };
    });
  };

  const handleToggleMusic = () => {
    setProfile((prev) => {
      const next = !prev.ambientMusicPlaying;
      if (next) {
        startAmbientMusic();
      } else {
        stopAmbientMusic();
      }
      return { ...prev, ambientMusicPlaying: next };
    });
  };

  const handleSaveBouquet = (newBouquet: BouquetGift) => {
    setBouquets((prev) => [newBouquet, ...prev]);
  };

  const handleDeleteBouquet = (id: string) => {
    setBouquets((prev) => prev.filter((b) => b.id !== id));
  };

  const handleAddNote = (newNote: DailyNote) => {
    setNotes((prev) => [newNote, ...prev]);
  };

  const handleDeleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
  };

  const handleTogglePinNote = (id: string) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isPinned: !n.isPinned } : n))
    );
  };

  const handleAddMemory = (newMemory: MemoryPhoto) => {
    setMemories((prev) => [newMemory, ...prev]);
  };

  const handleDeleteMemory = (id: string) => {
    setMemories((prev) => prev.filter((m) => m.id !== id));
  };

  const handleToggleFavoriteMemory = (id: string) => {
    setMemories((prev) =>
      prev.map((m) => (m.id === id ? { ...m, isFavorite: !m.isFavorite } : m))
    );
  };

  return (
    <div className="min-h-screen bg-kitty-pattern text-[#5C3A4D] relative flex flex-col font-cute selection:bg-pink-200 selection:text-pink-900">
      {/* Animated Floating Sparkles & Heart Physics Canvas */}
      <SparkleCanvas />

      {/* Main Header / Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        profile={profile}
        onOpenSettings={() => {
          setIsSettingsOpen(true);
          playSound('pop', profile.soundEnabled);
        }}
        onToggleSound={handleToggleSound}
        onToggleMusic={handleToggleMusic}
      />

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {activeTab === 'admiration' && (
          <AdmirationHero
            profile={profile}
            onNavigateToBouquet={() => {
              setActiveTab('bouquet');
              playSound('chime', profile.soundEnabled);
            }}
            onNavigateToNotes={() => {
              setActiveTab('notes');
              playSound('chime', profile.soundEnabled);
            }}
          />
        )}

        {activeTab === 'bouquet' && (
          <BouquetBuilder
            profile={profile}
            bouquets={bouquets}
            onSaveBouquet={handleSaveBouquet}
            onDeleteBouquet={handleDeleteBouquet}
          />
        )}

        {activeTab === 'notes' && (
          <DailyNotes
            profile={profile}
            notes={notes}
            onAddNote={handleAddNote}
            onDeleteNote={handleDeleteNote}
            onTogglePin={handleTogglePinNote}
          />
        )}

        {activeTab === 'gallery' && (
          <PhotoGallery
            profile={profile}
            memories={memories}
            onAddMemory={handleAddMemory}
            onDeleteMemory={handleDeleteMemory}
            onToggleFavorite={handleToggleFavoriteMemory}
          />
        )}
      </main>

      {/* Sweet Footer */}
      <footer className="relative z-10 bg-white/90 border-t-2 border-pink-200/80 py-8 px-4 text-center mt-12 backdrop-blur-xs">
        <div className="max-w-4xl mx-auto space-y-3">
          <div className="flex items-center justify-center gap-2">
            <div className="w-10 h-10 rounded-full bg-pink-100 border border-pink-300 flex items-center justify-center">
              <HelloKittyIcon size={32} expression="love" />
            </div>
            <span className="font-bold text-base sm:text-lg font-cute text-pink-950">
              Forever {profile.hisName} & {profile.herName}
            </span>
          </div>

          <p className="text-xs sm:text-sm text-pink-700 font-handwriting text-lg">
            "You will always be my favorite Hello Kitty bow, my sweetest melody, and my forever home." 🎀💖
          </p>

          <div className="flex items-center justify-center gap-4 text-xs text-pink-500 font-medium pt-2">
            <span>Crafted with endless admiration</span>
            <span>•</span>
            <span>Always & Forever</span>
          </div>
        </div>
      </footer>

      {/* Settings Modal */}
      <CoupleSettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        profile={profile}
        onSaveProfile={(updated) => setProfile(updated)}
      />

      {/* Floating Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={() => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
            playSound('pop', profile.soundEnabled);
          }}
          className="fixed bottom-6 right-6 z-40 p-3 rounded-full bg-rose-500 hover:bg-rose-600 text-white shadow-lg border-2 border-white transition-all transform hover:scale-110 active:scale-95 cursor-pointer animate-bounce"
          title="Back to top"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}
    </div>
  );
}
