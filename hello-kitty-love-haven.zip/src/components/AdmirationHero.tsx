import React, { useState } from 'react';
import { Sparkles, Heart, Gift, Stars, ChevronRight, RefreshCw, Quote } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CoupleProfile, LoveReason } from '../types';
import { HelloKittyIcon } from './HelloKittyIcon';
import { LOVE_REASONS } from '../utils/data';
import { playSound } from '../utils/audio';

interface AdmirationHeroProps {
  profile: CoupleProfile;
  onNavigateToBouquet: () => void;
  onNavigateToNotes: () => void;
}

export const AdmirationHero: React.FC<AdmirationHeroProps> = ({
  profile,
  onNavigateToBouquet,
  onNavigateToNotes,
}) => {
  const [currentReasonIndex, setCurrentReasonIndex] = useState<number>(0);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);
  const [revealedReasons, setRevealedReasons] = useState<LoveReason[]>([LOVE_REASONS[0]]);
  const [loveMeter, setLoveMeter] = useState<number>(9999);
  const [loveBubbleText, setLoveBubbleText] = useState<string>('Click to send infinite love boosts! 💖');

  const currentReason = LOVE_REASONS[currentReasonIndex];

  const handleDrawReason = () => {
    setIsDrawing(true);
    playSound('pop', profile.soundEnabled);

    setTimeout(() => {
      const nextIndex = (currentReasonIndex + 1) % LOVE_REASONS.length;
      setCurrentReasonIndex(nextIndex);
      const newReason = LOVE_REASONS[nextIndex];
      if (!revealedReasons.find((r) => r.id === newReason.id)) {
        setRevealedReasons((prev) => [...prev, newReason]);
      }
      setIsDrawing(false);
      playSound('sparkle', profile.soundEnabled);

      // Trigger soft cute confetti
      confetti({
        particleCount: 20,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#FF70A6', '#FFD166', '#FFB7B2', '#FF99C8'],
        disableForReducedMotion: true,
      });
    }, 450);
  };

  const handleBoostLove = (e: React.MouseEvent) => {
    playSound('heart', profile.soundEnabled);
    setLoveMeter((prev) => prev + 100);

    const compliments = [
      `Aymaan thinks you are the prettiest angel! 🌸`,
      `Warning: Extreme cuteness detected in ${profile.herName}! 🎀`,
      `Grateful level +1000! You are my greatest blessing ✨`,
      `You stole Aymaan's heart and he never wants it back! 💖`,
      `Sending 1,000,000 warm forehead kisses right now! 🧸`,
      `Luckiest boy in the universe confirmed! 🍀`,
    ];
    const randomComp = compliments[Math.floor(Math.random() * compliments.length)];
    setLoveBubbleText(randomComp);

    const rect = e.currentTarget.getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    confetti({
      particleCount: 25,
      spread: 50,
      origin: { x, y },
      colors: ['#FF2A55', '#FF70A6', '#FFB7B2', '#FFE5EC'],
    });
  };

  return (
    <div className="space-y-8 sm:space-y-12">
      {/* Hero Admiration Card */}
      <section className="relative overflow-hidden rounded-3xl bg-linear-to-br from-pink-100/90 via-rose-50/80 to-pink-100/90 border-2 border-pink-300 p-6 sm:p-10 shadow-md">
        {/* Soft Decorative Elements */}
        <div className="absolute top-3 left-4 text-pink-300 select-none animate-float-gentle text-2xl">🎀</div>
        <div className="absolute top-4 right-6 text-pink-300 select-none animate-sparkle text-2xl">✨</div>
        <div className="absolute bottom-4 left-6 text-pink-200 select-none animate-float-slow text-3xl">🌸</div>

        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-6 sm:gap-10">
          {/* Hello Kitty Cute Mascot Visual */}
          <div className="relative shrink-0 flex flex-col items-center">
            <div className="relative w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-white border-4 border-pink-300 flex items-center justify-center shadow-lg p-2 animate-float-slow">
              <HelloKittyIcon size={120} expression="love" />
              {/* Cute Floating Heart Badge */}
              <div className="absolute -top-2 -right-2 bg-rose-500 text-white p-2 rounded-full border-2 border-white shadow-md animate-bounce">
                <Heart className="w-5 h-5 fill-white text-white" />
              </div>
            </div>

            <div className="mt-3 px-3 py-1 rounded-full bg-rose-500 text-white font-cute text-xs font-semibold shadow-xs flex items-center gap-1">
              <span>My Whole World</span>
              <Sparkles className="w-3 h-3 text-yellow-200" />
            </div>
          </div>

          {/* Sincere Letter & Admiration Text */}
          <div className="text-center md:text-left flex-1 space-y-3">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-white/90 border border-pink-300 text-rose-600 text-xs font-bold shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-rose-500" />
              <span>A Love Letter For {profile.herName}</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-bold font-cute text-pink-950 tracking-tight leading-snug">
              Every single day, I am so grateful and overwhelmingly lucky to have you.
            </h2>

            <p className="text-pink-900/80 text-sm sm:text-base leading-relaxed font-body">
              Out of everything in my life, meeting you and loving you is the easiest, most beautiful miracle. 
              Your gentleness turns my hard days soft, your laughter is my favorite song, and your sweet smile 
              is my forever home. I admire your kind soul and cherish you more than words could ever convey.
            </p>

            {/* Quick Action Buttons */}
            <div className="pt-2 flex flex-wrap items-center justify-center md:justify-start gap-3">
              <button
                id="hero-make-bouquet-btn"
                onClick={onNavigateToBouquet}
                className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 text-white font-semibold text-sm shadow-md transition-transform hover:scale-105 active:scale-95 cursor-pointer"
              >
                <Gift className="w-4 h-4" />
                <span>Gift Her A Digital Bouquet 💐</span>
              </button>

              <button
                id="hero-read-notes-btn"
                onClick={onNavigateToNotes}
                className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-white hover:bg-pink-50 text-pink-800 border-2 border-pink-300 font-semibold text-sm shadow-xs transition-transform hover:scale-105 active:scale-95 cursor-pointer"
              >
                <span>Read Sweet Love Notes 💌</span>
                <ChevronRight className="w-4 h-4 text-pink-500" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Grid Section: Jar of Reasons + Affection Gauge */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        {/* Left: Jar of 100 Reasons Why I Adore You (7 cols) */}
        <section className="lg:col-span-7 bg-white rounded-3xl border-2 border-pink-200 p-6 sm:p-8 shadow-xs flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-pink-100 text-rose-500 flex items-center justify-center font-bold text-lg border border-pink-200">
                  💖
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl font-bold font-cute text-pink-950">
                    Jar of Reasons Why I Adore You
                  </h3>
                  <p className="text-xs text-pink-600 font-medium">
                    Pick a star from the jar to reveal why you make my heart flutter!
                  </p>
                </div>
              </div>

              <span className="px-3 py-1 rounded-full bg-pink-50 border border-pink-200 text-xs font-semibold text-pink-700">
                Reason #{currentReason.id} of {LOVE_REASONS.length}+
              </span>
            </div>

            {/* Revealed Reason Card */}
            <div className="relative mt-4 p-6 sm:p-8 rounded-2xl bg-linear-to-br from-pink-50 via-rose-50/50 to-pink-50 border-2 border-pink-200/90 shadow-inner">
              <Quote className="absolute top-4 right-4 w-8 h-8 text-pink-200 rotate-180" />
              
              <div className="flex items-center gap-2 mb-2">
                <span className="text-2xl">{currentReason.icon}</span>
                <span className="text-xs font-bold uppercase tracking-wider text-rose-500 bg-white px-2.5 py-0.5 rounded-full border border-pink-200">
                  {currentReason.tag}
                </span>
              </div>

              <h4 className="text-lg sm:text-xl font-bold text-pink-900 font-cute mb-2">
                {currentReason.title}
              </h4>

              <p className="text-pink-800 text-sm sm:text-base leading-relaxed font-body">
                "{currentReason.description}"
              </p>

              <div className="mt-4 pt-3 border-t border-pink-200/60 flex items-center justify-between text-xs text-pink-600 font-handwriting text-base font-semibold">
                <span>With all my affection 🎀</span>
                <span>— {profile.hisName}</span>
              </div>
            </div>
          </div>

          {/* Draw Button & Star Tray */}
          <div className="mt-6 pt-4 border-t border-pink-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            {/* Visual Mini Star Capsules */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-1">
              {LOVE_REASONS.slice(0, 8).map((r, i) => (
                <button
                  key={r.id}
                  onClick={() => {
                    setCurrentReasonIndex(i);
                    playSound('sparkle', profile.soundEnabled);
                  }}
                  className={`w-7 h-7 rounded-full text-xs flex items-center justify-center transition-all cursor-pointer ${
                    i === currentReasonIndex
                      ? 'bg-rose-500 text-white scale-110 shadow-xs ring-2 ring-pink-300'
                      : 'bg-pink-100 text-pink-700 hover:bg-pink-200'
                  }`}
                  title={`Reason #${r.id}: ${r.title}`}
                >
                  {r.icon}
                </button>
              ))}
              <span className="text-xs text-pink-400 font-bold ml-1">+more</span>
            </div>

            <button
              id="draw-next-reason-btn"
              onClick={handleDrawReason}
              disabled={isDrawing}
              className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-linear-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-bold text-sm shadow-md transition-transform hover:scale-105 active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${isDrawing ? 'animate-spin' : ''}`} />
              <span>Draw Another Star 🌟</span>
            </button>
          </div>
        </section>

        {/* Right: Affection Meter & Hello Kitty Compliment Box (5 cols) */}
        <section className="lg:col-span-5 bg-white rounded-3xl border-2 border-pink-200 p-6 sm:p-8 shadow-xs flex flex-col justify-between">
          <div className="space-y-5">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-2xl bg-rose-100 text-rose-500 flex items-center justify-center font-bold text-lg border border-rose-200">
                🎀
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-bold font-cute text-pink-950">
                  Affection Meter
                </h3>
                <p className="text-xs text-pink-600 font-medium">
                  Real-time love gauge for {profile.herName}
                </p>
              </div>
            </div>

            {/* Gauge Display */}
            <div className="p-5 rounded-2xl bg-pink-50/80 border-2 border-pink-200 text-center space-y-2">
              <span className="text-xs font-bold text-pink-600 uppercase tracking-widest">
                Love Power Level
              </span>
              <div className="text-3xl sm:text-4xl font-extrabold font-cute text-rose-600 flex items-center justify-center gap-1">
                <span>{loveMeter.toLocaleString()}%</span>
                <Heart className="w-6 h-6 fill-rose-500 text-rose-500 animate-heartbeat" />
              </div>
              <div className="w-full bg-pink-200 h-3 rounded-full overflow-hidden p-0.5">
                <div className="bg-linear-to-r from-pink-400 via-rose-500 to-red-400 h-full rounded-full w-full animate-pulse"></div>
              </div>
              <p className="text-xs text-pink-700 font-medium">Status: Mathematically Infinite & Beyond 🚀</p>
            </div>

            {/* Reactive Hello Kitty Speech Bubble */}
            <div className="relative p-4 rounded-2xl bg-white border-2 border-rose-200 shadow-xs flex items-center gap-3">
              <div className="shrink-0 w-12 h-12 rounded-full bg-pink-100 border border-pink-300 flex items-center justify-center">
                <HelloKittyIcon size={38} expression="happy" />
              </div>
              <p className="text-xs sm:text-sm font-semibold text-pink-900 leading-snug">
                "{loveBubbleText}"
              </p>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-pink-100">
            <button
              id="boost-love-meter-btn"
              onClick={handleBoostLove}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl bg-rose-500 hover:bg-rose-600 active:scale-98 text-white font-bold text-sm shadow-md transition-all cursor-pointer group"
            >
              <Heart className="w-4 h-4 fill-white text-white group-hover:scale-125 transition-transform" />
              <span>Tap To Send Love Boost 💖</span>
              <Sparkles className="w-4 h-4 text-yellow-200" />
            </button>
          </div>
        </section>
      </div>

      {/* 4 Pillars of Admiration Grid */}
      <section className="bg-pink-50/70 rounded-3xl border-2 border-pink-200/90 p-6 sm:p-8 shadow-xs">
        <div className="text-center max-w-2xl mx-auto mb-6 space-y-1">
          <span className="text-xs font-bold text-rose-500 uppercase tracking-wider">
            Treasured Qualities
          </span>
          <h3 className="text-xl sm:text-2xl font-bold font-cute text-pink-950">
            Four Things I Cherish Most About You
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              icon: '✨',
              title: 'Your Radiant Energy',
              desc: 'You have a gentle light that makes anyone around you feel valued and at ease.',
            },
            {
              icon: '🧸',
              title: 'Your Warm Heart',
              desc: 'The purest compassion and care that you pour into everything you do.',
            },
            {
              icon: '🌸',
              title: 'Your Lovely Smile',
              desc: 'One smile from you can instantly turn my entire day into sweet sunshine.',
            },
            {
              icon: '💍',
              title: 'Our Sweet Future',
              desc: 'Growing together, holding hands, and creating a lifetime of gentle memories.',
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-pink-200 p-5 shadow-2xs hover:border-pink-300 hover:shadow-xs transition-all space-y-2 text-center"
            >
              <div className="text-3xl mb-1">{item.icon}</div>
              <h4 className="font-bold text-pink-900 text-base font-cute">{item.title}</h4>
              <p className="text-xs text-pink-700 leading-relaxed font-body">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
