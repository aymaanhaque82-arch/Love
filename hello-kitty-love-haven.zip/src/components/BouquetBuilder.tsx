import React, { useState } from 'react';
import { Plus, Minus, Heart, Gift, Sparkles, Send, Tag, BookOpen, Trash2, Eye } from 'lucide-react';
import confetti from 'canvas-confetti';
import { BouquetGift, CoupleProfile, FlowerItem } from '../types';
import { FLOWER_CATALOG, WRAPPING_STYLES } from '../utils/data';
import { FlowerSVG } from './FlowerSVG';
import { HelloKittyIcon } from './HelloKittyIcon';
import { playSound } from '../utils/audio';

interface BouquetBuilderProps {
  profile: CoupleProfile;
  bouquets: BouquetGift[];
  onSaveBouquet: (bouquet: BouquetGift) => void;
  onDeleteBouquet: (id: string) => void;
}

export const BouquetBuilder: React.FC<BouquetBuilderProps> = ({
  profile,
  bouquets,
  onSaveBouquet,
  onDeleteBouquet,
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'vault'>('create');
  const [selectedWrapping, setSelectedWrapping] = useState<string>('pink-gingham');
  const [selectedRibbon, setSelectedRibbon] = useState<string>('#FF3366');
  const [flowerCounts, setFlowerCounts] = useState<Record<string, number>>({
    'pink-tulip': 3,
    'red-rose': 2,
    'kitty-bow-flower': 2,
    'babys-breath': 4,
  });
  const [bouquetTitle, setBouquetTitle] = useState<string>('A Bouquet of Endless Kisses 🎀');
  const [bouquetNote, setBouquetNote] = useState<string>(
    `To ${profile.herName},\n\nEvery single blossom in this bouquet represents another reason why I fall in love with you every day. Thank you for filling my world with sweetness and warmth. You are my forever favorite flower. 🌸💖`
  );
  const [viewingGift, setViewingGift] = useState<BouquetGift | null>(null);
  const [isGiftingCelebration, setIsGiftingCelebration] = useState<boolean>(false);

  const totalFlowerCount = Object.values(flowerCounts).reduce((a: number, b: number) => a + Number(b), 0);

  const handleFlowerCountChange = (flowerId: string, delta: number) => {
    playSound('pop', profile.soundEnabled);
    setFlowerCounts((prev) => {
      const current = prev[flowerId] || 0;
      const updated = Math.max(0, Math.min(8, current + delta));
      return { ...prev, [flowerId]: updated };
    });
  };

  const handleGiftBouquet = () => {
    if (totalFlowerCount === 0) {
      alert('Please add at least one flower to your sweet bouquet!');
      return;
    }

    playSound('harp', profile.soundEnabled);

    const flowersList = (Object.entries(flowerCounts) as [string, number][])
      .filter(([_, count]) => count > 0)
      .map(([id, count]) => {
        const flower = FLOWER_CATALOG.find((f) => f.id === id)!;
        return {
          flowerId: id,
          count: Number(count),
          name: flower.name,
          color: flower.color,
          meaning: flower.meaning,
        };
      });

    const newBouquet: BouquetGift = {
      id: `b-${Date.now()}`,
      title: bouquetTitle.trim() || 'My Sweetest Digital Bouquet 🎀',
      recipientName: profile.herName,
      senderName: profile.hisName,
      date: new Date().toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      }),
      wrappingStyle: selectedWrapping as BouquetGift['wrappingStyle'],
      ribbonColor: selectedRibbon,
      flowers: flowersList,
      note: bouquetNote,
      greetingCardTheme: 'kitty-classic',
    };

    onSaveBouquet(newBouquet);
    setViewingGift(newBouquet);
    setIsGiftingCelebration(true);

    // Shower with love confetti & flowers
    confetti({
      particleCount: 80,
      spread: 100,
      origin: { y: 0.6 },
      colors: ['#FF2A55', '#FF70A6', '#FFAFCC', '#FFD166', '#CDB4DB'],
    });
  };

  const currentWrappingObj = WRAPPING_STYLES.find((w) => w.id === selectedWrapping) || WRAPPING_STYLES[0];

  return (
    <div className="space-y-8">
      {/* Header Banner with Sub-Navigation */}
      <div className="bg-white rounded-3xl border-2 border-pink-200 p-6 sm:p-8 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-pink-300 flex items-center justify-center text-2xl shadow-xs">
            💐
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold font-cute text-pink-950">
              Interactive Digital Bouquet Studio
            </h2>
            <p className="text-xs sm:text-sm text-pink-700 font-medium">
              Handpick romantic blooms, choose cute wrapping, and gift an eternal digital bouquet to {profile.herName}.
            </p>
          </div>
        </div>

        {/* Tab switch */}
        <div className="flex items-center p-1 bg-pink-100/80 rounded-2xl border border-pink-200">
          <button
            id="bouquet-tab-create"
            onClick={() => {
              setActiveTab('create');
              playSound('pop', profile.soundEnabled);
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'create'
                ? 'bg-rose-500 text-white shadow-xs'
                : 'text-pink-800 hover:text-pink-950'
            }`}
          >
            Craft A Bouquet 🎀
          </button>
          <button
            id="bouquet-tab-vault"
            onClick={() => {
              setActiveTab('vault');
              playSound('pop', profile.soundEnabled);
            }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              activeTab === 'vault'
                ? 'bg-rose-500 text-white shadow-xs'
                : 'text-pink-800 hover:text-pink-950'
            }`}
          >
            <span>Gifted Garden ({bouquets.length})</span>
            <Sparkles className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {activeTab === 'create' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Bouquet Customization Controls (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Step 1: Pick Flowers */}
            <div className="bg-white rounded-3xl border-2 border-pink-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-rose-500 text-white text-xs font-bold flex items-center justify-center">
                    1
                  </span>
                  <h3 className="font-bold font-cute text-lg text-pink-950">
                    Select Your Stems ({totalFlowerCount} selected)
                  </h3>
                </div>
                <span className="text-xs text-pink-600 font-semibold">
                  Mix & Match Stems
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {FLOWER_CATALOG.map((flower) => {
                  const count = flowerCounts[flower.id] || 0;
                  return (
                    <div
                      key={flower.id}
                      className={`p-3 rounded-2xl border transition-all flex flex-col justify-between ${
                        count > 0
                          ? 'bg-pink-50/90 border-rose-400 shadow-xs'
                          : 'bg-white border-pink-100 hover:border-pink-200'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-10 h-10 shrink-0 bg-white rounded-xl border border-pink-200 flex items-center justify-center p-1">
                          <FlowerSVG type={flower.svgType} color={flower.color} size={32} />
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-bold text-xs text-pink-950 truncate">{flower.name}</h4>
                          <p className="text-[10px] text-pink-600 truncate">{flower.koreanName}</p>
                        </div>
                      </div>

                      <p className="text-[11px] text-pink-800 line-clamp-2 mb-3 italic font-body">
                        "{flower.meaning}"
                      </p>

                      <div className="flex items-center justify-between bg-white rounded-xl p-1 border border-pink-200">
                        <button
                          onClick={() => handleFlowerCountChange(flower.id, -1)}
                          disabled={count === 0}
                          className="w-6 h-6 rounded-lg bg-pink-100 text-pink-800 flex items-center justify-center hover:bg-pink-200 disabled:opacity-30 cursor-pointer"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-bold text-pink-950 font-cute">{count}</span>
                        <button
                          onClick={() => handleFlowerCountChange(flower.id, 1)}
                          className="w-6 h-6 rounded-lg bg-rose-500 text-white flex items-center justify-center hover:bg-rose-600 cursor-pointer"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Step 2: Choose Wrapping & Ribbon */}
            <div className="bg-white rounded-3xl border-2 border-pink-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-rose-500 text-white text-xs font-bold flex items-center justify-center">
                  2
                </span>
                <h3 className="font-bold font-cute text-lg text-pink-950">
                  Wrapping Paper & Ribbon
                </h3>
              </div>

              {/* Wrapping Styles */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-pink-800 uppercase tracking-wider">
                  Wrapping Style:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  {WRAPPING_STYLES.map((w) => (
                    <button
                      key={w.id}
                      onClick={() => {
                        setSelectedWrapping(w.id);
                        playSound('pop', profile.soundEnabled);
                      }}
                      className={`p-2.5 rounded-2xl border-2 text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                        selectedWrapping === w.id
                          ? 'border-rose-500 ring-2 ring-pink-200 shadow-xs'
                          : 'border-pink-100 hover:border-pink-300'
                      }`}
                    >
                      <div
                        className={`w-6 h-6 rounded-xl border border-pink-300 shadow-2xs ${w.patternClass}`}
                        style={{ backgroundColor: w.color }}
                      />
                      <span className="text-xs font-bold text-pink-900 truncate">{w.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Ribbon Colors */}
              <div className="space-y-2 pt-2">
                <label className="text-xs font-bold text-pink-800 uppercase tracking-wider">
                  Ribbon Accent:
                </label>
                <div className="flex items-center gap-3">
                  {[
                    { color: '#FF3366', name: 'Ruby Pink Bow' },
                    { color: '#D90429', name: 'Classic Red Bow' },
                    { color: '#FFAFCC', name: 'Sweet Pastel Bow' },
                    { color: '#9D4EDD', name: 'Royal Violet' },
                    { color: '#FFD166', name: 'Golden Honey' },
                  ].map((r) => (
                    <button
                      key={r.color}
                      onClick={() => {
                        setSelectedRibbon(r.color);
                        playSound('pop', profile.soundEnabled);
                      }}
                      className={`w-8 h-8 rounded-full border-2 transition-transform cursor-pointer flex items-center justify-center ${
                        selectedRibbon === r.color
                          ? 'scale-115 border-pink-950 ring-2 ring-pink-300'
                          : 'border-white hover:scale-105'
                      }`}
                      style={{ backgroundColor: r.color }}
                      title={r.name}
                    >
                      {selectedRibbon === r.color && <Sparkles className="w-4 h-4 text-white" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Step 3: Personalized Love Note Card */}
            <div className="bg-white rounded-3xl border-2 border-pink-200 p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-rose-500 text-white text-xs font-bold flex items-center justify-center">
                    3
                  </span>
                  <h3 className="font-bold font-cute text-lg text-pink-950">
                    Handwritten Love Tag Note
                  </h3>
                </div>
                <Tag className="w-4 h-4 text-rose-500" />
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-pink-800 mb-1">Bouquet Name:</label>
                  <input
                    id="bouquet-title-input"
                    type="text"
                    value={bouquetTitle}
                    onChange={(e) => setBouquetTitle(e.target.value)}
                    className="w-full px-4 py-2 rounded-xl bg-pink-50 border border-pink-200 font-cute text-sm text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                    placeholder="e.g. A Bloom of Forever Love 🎀"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-pink-800 mb-1">Sweet Message on Tag:</label>
                  <textarea
                    id="bouquet-note-textarea"
                    rows={4}
                    value={bouquetNote}
                    onChange={(e) => setBouquetNote(e.target.value)}
                    className="w-full p-4 rounded-xl bg-[#FFFDF9] border-2 border-pink-200 font-handwriting text-lg text-pink-900 focus:outline-none focus:ring-2 focus:ring-rose-400 leading-relaxed"
                    placeholder="Write a sweet message from your heart..."
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Interactive Bouquet Visualizer (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="sticky top-28 bg-white rounded-3xl border-2 border-pink-300 p-6 sm:p-8 shadow-md flex flex-col items-center">
              <div className="w-full flex items-center justify-between pb-3 border-b border-pink-100 mb-4">
                <span className="text-xs font-bold text-rose-600 uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Bouquet Arrangement Preview</span>
                </span>
                <span className="text-xs font-cute font-bold text-pink-700 bg-pink-100 px-3 py-0.5 rounded-full">
                  {totalFlowerCount} Blossoms
                </span>
              </div>

              {/* Bouquet Arrangement Visual Stage */}
              <div className="relative w-full aspect-4/5 max-w-sm rounded-3xl bg-linear-to-b from-pink-50/60 to-rose-50/40 border-2 border-pink-200 flex flex-col items-center justify-center p-6 overflow-hidden shadow-inner">
                {/* Floating sparkles & petals */}
                <div className="absolute top-4 left-4 text-pink-300 text-lg animate-sparkle">✨</div>
                <div className="absolute top-8 right-6 text-pink-300 text-lg animate-sparkle">🌸</div>
                <div className="absolute bottom-16 left-6 text-pink-300 text-lg animate-sparkle">✨</div>

                {/* Flowers Layered on Top */}
                <div className="relative z-10 w-full flex-1 flex flex-wrap items-center justify-center gap-1 p-2 pt-4">
                  {totalFlowerCount === 0 ? (
                    <div className="text-center p-4">
                      <div className="w-16 h-16 rounded-full bg-pink-100 mx-auto flex items-center justify-center mb-2">
                        <FlowerSVG type="tulip" color="#FFB3C6" size={40} />
                      </div>
                      <p className="text-xs font-bold text-pink-400 font-cute">
                        Add flowers on the left to watch your bouquet bloom!
                      </p>
                    </div>
                  ) : (
                    (Object.entries(flowerCounts) as [string, number][]).map(([id, count]) => {
                      if (count === 0) return null;
                      const flower = FLOWER_CATALOG.find((f) => f.id === id)!;
                      return Array.from({ length: Number(count) }).map((_, idx) => (
                        <div
                          key={`${id}-${idx}`}
                          className="transition-transform hover:scale-115 cursor-pointer -m-2 sm:-m-1.5 animate-float-gentle"
                          style={{
                            transform: `rotate(${(idx % 5 - 2) * 8}deg) scale(${0.85 + (idx % 3) * 0.1})`,
                          }}
                          title={`${flower.name}: ${flower.meaning}`}
                        >
                          <FlowerSVG type={flower.svgType} color={flower.color} size={68} />
                        </div>
                      ));
                    })
                  )}
                </div>

                {/* Wrapping Paper Cone Visual Base */}
                <div className="relative z-20 w-full max-w-56 -mt-8 flex flex-col items-center">
                  <div
                    className={`w-full h-32 rounded-b-3xl border-2 shadow-md relative overflow-hidden flex flex-col items-center justify-center ${currentWrappingObj.patternClass}`}
                    style={{
                      backgroundColor: currentWrappingObj.color,
                      borderColor: currentWrappingObj.border,
                    }}
                  >
                    {/* Hello Kitty Cute Emblem on Wrapping */}
                    <div className="w-14 h-14 rounded-full bg-white/95 border-2 border-pink-300 shadow-sm flex items-center justify-center mb-1">
                      <HelloKittyIcon size={42} expression="happy" />
                    </div>
                    <span className="text-[10px] font-bold text-pink-900 font-cute bg-white/80 px-2 py-0.5 rounded-full border border-pink-200">
                      With Endless Love
                    </span>
                  </div>

                  {/* Ribbon Knot */}
                  <div
                    className="absolute -top-3 w-10 h-10 rounded-full border-2 border-white shadow-md flex items-center justify-center"
                    style={{ backgroundColor: selectedRibbon }}
                  >
                    <span className="text-white text-xs">🎀</span>
                  </div>
                </div>
              </div>

              {/* Gift Bouquet Action Button */}
              <div className="w-full mt-6 space-y-2">
                <button
                  id="gift-bouquet-submit-btn"
                  onClick={handleGiftBouquet}
                  disabled={totalFlowerCount === 0}
                  className="w-full flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-2xl bg-linear-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white font-bold text-sm sm:text-base shadow-lg transition-transform hover:scale-102 active:scale-98 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-5 h-5" />
                  <span>Deliver This Bouquet To Her 💖</span>
                  <Sparkles className="w-4 h-4 text-yellow-200" />
                </button>
                <p className="text-[11px] text-center text-pink-600 font-medium">
                  Triggers celebratory presentation & saves to your romantic garden
                </p>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Gifted Garden Vault Tab */
        <div className="space-y-6">
          {bouquets.length === 0 ? (
            <div className="bg-white rounded-3xl border-2 border-pink-200 p-12 text-center max-w-md mx-auto space-y-4">
              <div className="w-20 h-20 rounded-full bg-pink-100 mx-auto flex items-center justify-center text-3xl">
                💐
              </div>
              <h3 className="font-bold font-cute text-xl text-pink-950">Your Garden is Waiting</h3>
              <p className="text-xs text-pink-700 font-body">
                You haven't gifted any bouquets yet. Switch to the craft tab to make your first personalized bloom!
              </p>
              <button
                onClick={() => setActiveTab('create')}
                className="px-5 py-2.5 rounded-2xl bg-rose-500 text-white font-bold text-xs shadow-md cursor-pointer"
              >
                Craft A Bouquet Now 🎀
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {bouquets.map((b) => (
                <div
                  key={b.id}
                  className="bg-white rounded-3xl border-2 border-pink-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                >
                  {/* Card Header & Preview */}
                  <div className="p-6 bg-pink-50/60 border-b border-pink-100 flex flex-col items-center">
                    <span className="text-[11px] font-bold text-rose-600 bg-white px-3 py-0.5 rounded-full border border-pink-200 mb-2">
                      Gifted on {b.date}
                    </span>
                    <h4 className="font-bold font-cute text-base text-pink-950 text-center mb-3">
                      {b.title}
                    </h4>

                    {/* Flower icons row */}
                    <div className="flex items-center justify-center gap-1.5 flex-wrap">
                      {b.flowers.map((f, i) => {
                        const catalogItem = FLOWER_CATALOG.find((c) => c.id === f.flowerId);
                        return (
                          <div
                            key={i}
                            className="w-10 h-10 rounded-xl bg-white border border-pink-200 flex items-center justify-center p-1 shadow-2xs"
                            title={`${f.count}x ${f.name} (${f.meaning})`}
                          >
                            <FlowerSVG
                              type={catalogItem?.svgType || 'tulip'}
                              color={f.color}
                              size={28}
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Note snippet & actions */}
                  <div className="p-6 space-y-4">
                    <p className="text-xs text-pink-800 font-handwriting text-base line-clamp-3 leading-relaxed">
                      "{b.note}"
                    </p>

                    <div className="pt-3 border-t border-pink-100 flex items-center justify-between">
                      <button
                        onClick={() => {
                          setViewingGift(b);
                          playSound('sparkle', profile.soundEnabled);
                        }}
                        className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-rose-500 text-white font-bold text-xs hover:bg-rose-600 cursor-pointer shadow-xs"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Card</span>
                      </button>

                      <button
                        onClick={() => {
                          if (confirm('Are you sure you want to remove this bouquet from the garden?')) {
                            onDeleteBouquet(b.id);
                            playSound('pop', profile.soundEnabled);
                          }
                        }}
                        className="p-2 rounded-xl text-pink-400 hover:text-red-500 hover:bg-red-50 transition-colors cursor-pointer"
                        title="Delete bouquet"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Bouquet Unboxing / Fullscreen Presentation Modal */}
      {viewingGift && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-3xl border-4 border-pink-300 shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto space-y-6">
            <div className="absolute top-4 right-4">
              <button
                id="close-bouquet-modal-btn"
                onClick={() => {
                  setViewingGift(null);
                  setIsGiftingCelebration(false);
                }}
                className="w-8 h-8 rounded-full bg-pink-100 text-pink-800 font-bold hover:bg-pink-200 flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-center space-y-2">
              <div className="w-16 h-16 rounded-full bg-pink-100 border-2 border-pink-300 mx-auto flex items-center justify-center shadow-md animate-bounce">
                <HelloKittyIcon size={48} expression="love" />
              </div>
              <span className="text-xs font-bold uppercase tracking-wider text-rose-500">
                Special Delivery For {viewingGift.recipientName} 🎀
              </span>
              <h3 className="text-xl sm:text-2xl font-bold font-cute text-pink-950">
                {viewingGift.title}
              </h3>
              <p className="text-xs text-pink-600 font-medium">{viewingGift.date}</p>
            </div>

            {/* Bouquet Visual In Modal */}
            <div className="p-4 rounded-2xl bg-pink-50/80 border-2 border-pink-200 flex flex-wrap items-center justify-center gap-2">
              {viewingGift.flowers.map((f, idx) => {
                const catalogItem = FLOWER_CATALOG.find((c) => c.id === f.flowerId);
                return (
                  <div
                    key={idx}
                    className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full border border-pink-200 shadow-2xs"
                  >
                    <FlowerSVG type={catalogItem?.svgType || 'tulip'} color={f.color} size={24} />
                    <span className="text-xs font-bold text-pink-900">
                      {f.count}x {f.name}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Handwritten Letter Presentation */}
            <div className="p-6 rounded-2xl bg-[#FFFDF8] border-2 border-pink-200/90 shadow-sm space-y-3">
              <span className="text-xs font-bold text-pink-500 uppercase tracking-widest block border-b border-pink-200 pb-1">
                Handwritten Note Attached:
              </span>
              <p className="text-pink-900 font-handwriting text-xl sm:text-2xl leading-relaxed whitespace-pre-wrap">
                {viewingGift.note}
              </p>
              <div className="pt-2 text-right font-handwriting text-lg text-rose-600 font-bold">
                Forever yours, {viewingGift.senderName} 💖
              </div>
            </div>

            <div className="text-center">
              <button
                onClick={() => {
                  setViewingGift(null);
                  setIsGiftingCelebration(false);
                }}
                className="px-6 py-2.5 rounded-2xl bg-rose-500 text-white font-bold text-sm shadow-md hover:bg-rose-600 cursor-pointer"
              >
                Close & Keep In Heart 🌸
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
