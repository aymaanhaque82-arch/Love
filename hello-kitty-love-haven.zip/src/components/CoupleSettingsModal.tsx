import React, { useState } from 'react';
import { Heart, Calendar, User, Sparkles, Volume2, Music, Check } from 'lucide-react';
import { CoupleProfile } from '../types';
import { HelloKittyIcon } from './HelloKittyIcon';
import { playSound } from '../utils/audio';

interface CoupleSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: CoupleProfile;
  onSaveProfile: (profile: CoupleProfile) => void;
}

export const CoupleSettingsModal: React.FC<CoupleSettingsModalProps> = ({
  isOpen,
  onClose,
  profile,
  onSaveProfile,
}) => {
  const [herName, setHerName] = useState<string>(profile.herName);
  const [herNickname, setHerNickname] = useState<string>(profile.herNickname);
  const [hisName, setHisName] = useState<string>(profile.hisName);
  const [startDate, setStartDate] = useState<string>(profile.relationshipStartDate);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(profile.soundEnabled);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playSound('sparkle', soundEnabled);
    onSaveProfile({
      ...profile,
      herName: herName.trim() || 'My Girl 🎀',
      herNickname: herNickname.trim() || 'My Princess',
      hisName: hisName.trim() || 'Aymaan',
      relationshipStartDate: startDate || '2023-09-20',
      soundEnabled,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl border-4 border-pink-300 shadow-2xl p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-pink-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-2xl bg-pink-100 border border-pink-300 flex items-center justify-center">
              <HelloKittyIcon size={34} expression="happy" />
            </div>
            <div>
              <h3 className="text-xl font-bold font-cute text-pink-950">
                Personalize Haven 🎀
              </h3>
              <p className="text-[11px] text-pink-600 font-medium">Custom names & anniversary date</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-pink-100 text-pink-800 font-bold hover:bg-pink-200 flex items-center justify-center cursor-pointer"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-pink-800 mb-1">
              Her Name / Display Name:
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-pink-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={herName}
                onChange={(e) => setHerName(e.target.value)}
                placeholder="e.g. My Girl 🎀 or Her Name"
                className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-pink-50 border border-pink-200 text-sm font-cute text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-pink-800 mb-1">
              Her Cute Nickname:
            </label>
            <input
              type="text"
              value={herNickname}
              onChange={(e) => setHerNickname(e.target.value)}
              placeholder="e.g. My Cutie Princess, Angel, Honey"
              className="w-full px-4 py-2.5 rounded-xl bg-pink-50 border border-pink-200 text-sm font-cute text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-pink-800 mb-1">
              Your Name:
            </label>
            <input
              type="text"
              value={hisName}
              onChange={(e) => setHisName(e.target.value)}
              placeholder="e.g. Aymaan"
              className="w-full px-4 py-2.5 rounded-xl bg-pink-50 border border-pink-200 text-sm font-cute text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-pink-800 mb-1">
              Relationship / Anniversary Start Date:
            </label>
            <div className="relative">
              <Calendar className="w-4 h-4 text-pink-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-pink-50 border border-pink-200 text-sm font-cute text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                required
              />
            </div>
            <p className="text-[10px] text-pink-500 mt-1">
              Powers the "Days of Loving You" live counter at the top!
            </p>
          </div>

          <div className="pt-2 border-t border-pink-100 flex items-center justify-between">
            <span className="text-xs font-bold text-pink-800 flex items-center gap-1.5">
              <Volume2 className="w-4 h-4 text-rose-500" />
              <span>Cute Sound Effects</span>
            </span>
            <input
              type="checkbox"
              checked={soundEnabled}
              onChange={(e) => setSoundEnabled(e.target.checked)}
              className="w-4 h-4 accent-rose-500 rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-bold text-pink-700 hover:bg-pink-50 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs shadow-md cursor-pointer flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Save Changes 💖</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
