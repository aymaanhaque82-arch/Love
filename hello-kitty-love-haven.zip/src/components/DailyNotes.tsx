import React, { useState } from 'react';
import { Mail, Plus, Heart, Sparkles, Pin, Search, Lock, Unlock, RefreshCw, Feather, Smile, Coffee, Sun } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CoupleProfile, DailyNote, OpenWhenLetter } from '../types';
import { DAILY_LOVE_FORTUNES, INITIAL_OPEN_WHEN } from '../utils/data';
import { HelloKittyIcon } from './HelloKittyIcon';
import { playSound } from '../utils/audio';

interface DailyNotesProps {
  profile: CoupleProfile;
  notes: DailyNote[];
  onAddNote: (note: DailyNote) => void;
  onDeleteNote: (id: string) => void;
  onTogglePin: (id: string) => void;
}

export const DailyNotes: React.FC<DailyNotesProps> = ({
  profile,
  notes,
  onAddNote,
  onDeleteNote,
  onTogglePin,
}) => {
  const [openWhenLetters, setOpenWhenLetters] = useState<OpenWhenLetter[]>(INITIAL_OPEN_WHEN);
  const [selectedEnvelope, setSelectedEnvelope] = useState<OpenWhenLetter | null>(null);
  const [isComposing, setIsComposing] = useState<boolean>(false);
  const [fortuneIndex, setFortuneIndex] = useState<number>(0);
  const [fortuneRevealed, setFortuneRevealed] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Form states for new note
  const [noteTitle, setNoteTitle] = useState<string>('');
  const [noteContent, setNoteContent] = useState<string>('');
  const [noteStationery, setNoteStationery] = useState<DailyNote['stationery']>('pink-gingham');
  const [noteMood, setNoteMood] = useState<DailyNote['mood']>('loved');

  const handleRevealFortune = () => {
    playSound('sparkle', profile.soundEnabled);
    setFortuneRevealed(true);
    confetti({
      particleCount: 30,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FF2A55', '#FFB7B2', '#FFD166'],
    });
  };

  const handleNewFortune = () => {
    playSound('pop', profile.soundEnabled);
    setFortuneIndex((prev) => (prev + 1) % DAILY_LOVE_FORTUNES.length);
    setFortuneRevealed(true);
  };

  const handleOpenEnvelope = (letter: OpenWhenLetter) => {
    playSound('open', profile.soundEnabled);
    setSelectedEnvelope(letter);

    // mark as opened date if not already
    if (!letter.openedDate) {
      setOpenWhenLetters((prev) =>
        prev.map((item) =>
          item.id === letter.id
            ? {
                ...item,
                openedDate: new Date().toLocaleDateString('en-US', {
                  month: 'short',
                  day: 'numeric',
                }),
              }
            : item
        )
      );
    }
  };

  const handleCreateNoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noteTitle.trim() || !noteContent.trim()) {
      alert('Please fill in both title and message for your sweet note!');
      return;
    }

    playSound('chime', profile.soundEnabled);

    const newNote: DailyNote = {
      id: `note-${Date.now()}`,
      title: noteTitle.trim(),
      content: noteContent.trim(),
      date: 'Today',
      author: profile.hisName,
      stationery: noteStationery,
      mood: noteMood,
      isPinned: false,
    };

    onAddNote(newNote);
    setNoteTitle('');
    setNoteContent('');
    setIsComposing(false);

    confetti({
      particleCount: 25,
      spread: 50,
      origin: { y: 0.7 },
      colors: ['#FF70A6', '#FFAFCC', '#FFD166'],
    });
  };

  const stationeryStyles = {
    'pink-gingham': 'bg-pink-50 border-pink-300 text-pink-950',
    strawberry: 'bg-rose-50 border-rose-300 text-rose-950',
    'pastel-yellow': 'bg-amber-50 border-amber-200 text-amber-950',
    lavender: 'bg-purple-50 border-purple-200 text-purple-950',
    mint: 'bg-emerald-50 border-emerald-200 text-emerald-950',
  };

  const filteredNotes = notes.filter(
    (n) =>
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-10">
      {/* Top Section: Daily Love Fortune Scratch / Reveal Card */}
      <section className="bg-linear-to-r from-pink-100 via-rose-50 to-pink-100 rounded-3xl border-2 border-pink-300 p-6 sm:p-8 shadow-xs">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white border-2 border-pink-300 flex items-center justify-center shadow-xs shrink-0">
              <HelloKittyIcon size={46} expression={fortuneRevealed ? 'love' : 'wink'} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold uppercase tracking-wider">
                  Daily Secret
                </span>
                <span className="text-xs text-pink-700 font-semibold">Today's Sweet Fortune</span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold font-cute text-pink-950">
                Daily Love Capsule for {profile.herName}
              </h3>
            </div>
          </div>

          <div className="w-full md:w-auto flex items-center gap-3">
            {!fortuneRevealed ? (
              <button
                id="reveal-daily-fortune-btn"
                onClick={handleRevealFortune}
                className="w-full md:w-auto px-6 py-3 rounded-2xl bg-rose-500 hover:bg-rose-600 active:scale-95 text-white font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-yellow-200 animate-sparkle" />
                <span>Tap To Unseal Today's Message 🎀</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 w-full md:w-auto">
                <div className="px-4 py-2.5 rounded-2xl bg-white/95 border-2 border-pink-300 shadow-xs flex-1 md:max-w-md">
                  <p className="text-xs sm:text-sm font-bold text-pink-950 font-cute">
                    {DAILY_LOVE_FORTUNES[fortuneIndex]}
                  </p>
                </div>
                <button
                  onClick={handleNewFortune}
                  className="p-3 rounded-2xl bg-white border border-pink-300 text-pink-700 hover:bg-pink-100 transition-all cursor-pointer shrink-0"
                  title="Next sweet whisper"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Section 2: "Open When..." Envelopes Vault */}
      <section className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">💌</span>
            <div>
              <h3 className="text-xl sm:text-2xl font-bold font-cute text-pink-950">
                "Open When..." Sealed Letters
              </h3>
              <p className="text-xs text-pink-700 font-medium">
                Heartfelt emergency letters for every mood and moment
              </p>
            </div>
          </div>
          <span className="text-xs font-semibold text-pink-600 bg-pink-100 px-3 py-1 rounded-full">
            {openWhenLetters.length} Envelopes Ready
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {openWhenLetters.map((letter) => (
            <div
              key={letter.id}
              onClick={() => handleOpenEnvelope(letter)}
              className="group relative bg-white rounded-3xl border-2 border-pink-200 p-6 shadow-xs hover:shadow-md hover:border-pink-400 transition-all cursor-pointer flex flex-col justify-between"
            >
              {/* Envelope flap visual banner */}
              <div className="flex items-start justify-between gap-2 mb-3">
                <span className="text-3xl">{letter.icon}</span>
                {letter.openedDate ? (
                  <span className="px-2.5 py-0.5 rounded-full bg-pink-100 text-pink-700 text-[10px] font-bold flex items-center gap-1">
                    <Unlock className="w-3 h-3 text-pink-500" />
                    <span>Opened {letter.openedDate}</span>
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center gap-1">
                    <Lock className="w-3 h-3 text-white" />
                    <span>Sealed with Love 🎀</span>
                  </span>
                )}
              </div>

              <div className="space-y-2">
                <h4 className="font-bold font-cute text-base text-pink-950 group-hover:text-rose-600 transition-colors">
                  {letter.openWhen}
                </h4>
                <p className="text-xs text-pink-700 font-body line-clamp-2">
                  {letter.teaser}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-pink-100 flex items-center justify-between text-xs font-bold text-rose-500">
                <span>Click to open & read</span>
                <Sparkles className="w-3.5 h-3.5 group-hover:scale-125 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Section 3: Daily Sweet Notes Board */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-pink-200">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold font-cute text-pink-950 flex items-center gap-2">
              <span>Sweet Daily Notes Wall</span>
              <span className="text-base text-rose-500">📝</span>
            </h3>
            <p className="text-xs text-pink-700 font-medium">
              Daily messages, sweet reminders, and warm words written from the heart
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-pink-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search notes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-xl bg-white border border-pink-200 text-xs text-pink-950 placeholder-pink-300 focus:outline-none focus:ring-2 focus:ring-rose-400"
              />
            </div>

            {/* Write New Note Button */}
            <button
              id="write-new-note-btn"
              onClick={() => {
                setIsComposing(true);
                playSound('pop', profile.soundEnabled);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs sm:text-sm shadow-xs transition-transform hover:scale-105 active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Leave A Daily Note 🎀</span>
            </button>
          </div>
        </div>

        {/* Notes Grid with Washi Tape Sticky Aesthetic */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNotes.map((note) => (
            <div
              key={note.id}
              className={`relative p-6 rounded-3xl border-2 shadow-xs hover:shadow-md transition-all flex flex-col justify-between ${
                stationeryStyles[note.stationery] || stationeryStyles['pink-gingham']
              }`}
            >
              {/* Cute Washi Tape at Top Center */}
              <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 w-20 h-5 bg-pink-200/80 border border-pink-300/80 rounded-sm shadow-2xs rotate-[-2deg] select-none" />

              <div>
                <div className="flex items-center justify-between mb-3 pt-2">
                  <span className="text-[11px] font-bold text-pink-700 bg-white/70 px-2.5 py-0.5 rounded-full border border-pink-200/60">
                    {note.date}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => onTogglePin(note.id)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        note.isPinned
                          ? 'bg-rose-500 text-white'
                          : 'text-pink-400 hover:bg-white/60'
                      }`}
                      title={note.isPinned ? 'Unpin note' : 'Pin note to top'}
                    >
                      <Pin className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => {
                        if (confirm('Delete this sweet note?')) {
                          onDeleteNote(note.id);
                          playSound('pop', profile.soundEnabled);
                        }
                      }}
                      className="p-1.5 rounded-lg text-pink-400 hover:text-red-500 hover:bg-white/60 transition-colors cursor-pointer"
                      title="Delete note"
                    >
                      ✕
                    </button>
                  </div>
                </div>

                <h4 className="font-bold font-cute text-base text-pink-950 mb-2">
                  {note.title}
                </h4>

                <p className="text-pink-900 font-handwriting text-lg sm:text-xl leading-relaxed whitespace-pre-wrap">
                  "{note.content}"
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-pink-200/50 flex items-center justify-between text-xs font-semibold text-pink-700">
                <span>With love, {note.author} 💖</span>
                <span className="text-xs capitalize bg-white/80 px-2 py-0.5 rounded-full border border-pink-200">
                  Mood: {note.mood}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Modal: Read Opened Letter */}
      {selectedEnvelope && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-3xl border-4 border-pink-300 shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto space-y-6">
            <div className="absolute top-4 right-4">
              <button
                onClick={() => setSelectedEnvelope(null)}
                className="w-8 h-8 rounded-full bg-pink-100 text-pink-800 font-bold hover:bg-pink-200 flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="text-center space-y-2">
              <span className="text-4xl">{selectedEnvelope.icon}</span>
              <h3 className="text-xl sm:text-2xl font-bold font-cute text-pink-950">
                {selectedEnvelope.openWhen}
              </h3>
              <p className="text-xs text-pink-600 font-medium">{selectedEnvelope.teaser}</p>
            </div>

            <div className="p-6 sm:p-8 rounded-2xl bg-[#FFFDF8] border-2 border-pink-200 shadow-inner">
              <p className="text-pink-950 font-handwriting text-xl sm:text-2xl leading-relaxed whitespace-pre-wrap">
                {selectedEnvelope.content}
              </p>
            </div>

            <div className="text-center">
              <button
                onClick={() => setSelectedEnvelope(null)}
                className="px-6 py-2.5 rounded-2xl bg-rose-500 text-white font-bold text-sm shadow-md hover:bg-rose-600 cursor-pointer"
              >
                Close Letter 🌸
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Compose New Sweet Note */}
      {isComposing && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-3xl border-4 border-pink-300 shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto space-y-5">
            <div className="flex items-center justify-between border-b border-pink-100 pb-3">
              <div className="flex items-center gap-2">
                <Feather className="w-5 h-5 text-rose-500" />
                <h3 className="text-xl font-bold font-cute text-pink-950">
                  Write A Daily Love Message 💌
                </h3>
              </div>
              <button
                onClick={() => setIsComposing(false)}
                className="w-8 h-8 rounded-full bg-pink-100 text-pink-800 font-bold hover:bg-pink-200 flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNoteSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-pink-800 mb-1">
                  Note Title / Reminder:
                </label>
                <input
                  type="text"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  placeholder="e.g. Good morning to the prettiest girl in the world ☀️"
                  className="w-full px-4 py-2.5 rounded-xl bg-pink-50 border border-pink-200 text-sm font-cute text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-pink-800 mb-1">
                  Stationery Theme:
                </label>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {[
                    { id: 'pink-gingham', name: 'Pink Gingham', color: '#FFE0E9' },
                    { id: 'strawberry', name: 'Strawberry', color: '#FFE4E6' },
                    { id: 'pastel-yellow', name: 'Sunlight', color: '#FEF3C7' },
                    { id: 'lavender', name: 'Lavender', color: '#F3E8FF' },
                    { id: 'mint', name: 'Mint Leaf', color: '#D1FAE5' },
                  ].map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => setNoteStationery(s.id as DailyNote['stationery'])}
                      className={`p-2 rounded-xl text-center text-xs font-bold border-2 transition-all cursor-pointer ${
                        noteStationery === s.id
                          ? 'border-rose-500 ring-2 ring-pink-300 shadow-2xs'
                          : 'border-pink-200 hover:border-pink-400'
                      }`}
                      style={{ backgroundColor: s.color }}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-pink-800 mb-1">
                  Sweet Message:
                </label>
                <textarea
                  rows={5}
                  value={noteContent}
                  onChange={(e) => setNoteContent(e.target.value)}
                  placeholder="Write your sweet love note here..."
                  className="w-full p-4 rounded-xl bg-[#FFFDF9] border-2 border-pink-200 font-handwriting text-xl text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400 leading-relaxed"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsComposing(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-pink-700 hover:bg-pink-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <span>Pin To Wall 🎀</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
