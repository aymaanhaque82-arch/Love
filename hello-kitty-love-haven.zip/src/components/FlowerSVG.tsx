import React from 'react';

interface FlowerSVGProps {
  type: string;
  color?: string;
  size?: number;
  className?: string;
}

export const FlowerSVG: React.FC<FlowerSVGProps> = ({
  type,
  color = '#FF70A6',
  size = 64,
  className = '',
}) => {
  if (type === 'tulip') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        {/* Stem & Leaves */}
        <path d="M50 50 Q52 75 50 95" stroke="#70B77E" strokeWidth="4" strokeLinecap="round" />
        <path d="M49 70 Q30 65 35 52 Q48 58 49 70Z" fill="#88D49E" />
        <path d="M51 64 Q68 58 64 45 Q52 52 51 64Z" fill="#A7E8BD" />
        {/* Petals */}
        <path d="M30 45 C28 25 45 20 48 35 C42 42 35 48 30 45Z" fill={color} opacity="0.9" />
        <path d="M70 45 C72 25 55 20 52 35 C58 42 65 48 70 45Z" fill={color} opacity="0.9" />
        <path d="M36 48 C34 22 66 22 64 48 C60 58 40 58 36 48Z" fill={color} />
        <ellipse cx="50" cy="36" rx="7" ry="12" fill="#FFE5EC" opacity="0.4" />
      </svg>
    );
  }

  if (type === 'rose') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path d="M50 52 Q48 78 50 95" stroke="#52796F" strokeWidth="4" strokeLinecap="round" />
        <path d="M48 72 Q32 68 36 56 Q48 62 48 72Z" fill="#74A892" />
        <path d="M52 66 Q68 62 65 50 Q52 56 52 66Z" fill="#74A892" />
        {/* Rose Swirl Petals */}
        <circle cx="50" cy="38" r="22" fill={color} />
        <path d="M34 38 C34 26 66 26 66 38 C66 50 34 50 34 38Z" fill="#B7094C" opacity="0.3" />
        <path d="M40 34 C40 28 60 28 60 34 C60 42 40 42 40 34Z" fill={color} />
        <path d="M44 32 C44 29 56 29 56 32 C56 37 44 37 44 32Z" fill="#FFE3E0" />
        {/* Soft highlight */}
        <circle cx="48" cy="30" r="3" fill="#FFF" opacity="0.6" />
      </svg>
    );
  }

  if (type === 'cherry') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path d="M50 55 Q50 78 50 95" stroke="#A78B71" strokeWidth="3" strokeLinecap="round" />
        {/* 5 Petals */}
        {[0, 72, 144, 216, 288].map((angle, i) => (
          <g key={i} transform={`rotate(${angle} 50 40)`}>
            <path
              d="M50 40 C43 25 43 14 50 12 C57 14 57 25 50 40Z"
              fill={color}
            />
            <path d="M48 12 L50 15 L52 12" stroke="#FFF0F5" strokeWidth="1.5" />
          </g>
        ))}
        <circle cx="50" cy="40" r="7" fill="#FF4D6D" />
        <circle cx="50" cy="40" r="4" fill="#FFD166" />
        <circle cx="48" cy="38" r="1.5" fill="#FFF" />
      </svg>
    );
  }

  if (type === 'peony') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path d="M50 55 Q51 75 50 95" stroke="#588157" strokeWidth="4" strokeLinecap="round" />
        {/* Ruffled Peony Petals */}
        <circle cx="50" cy="38" r="26" fill={color} opacity="0.8" />
        <circle cx="43" cy="35" r="16" fill="#FFAFCC" />
        <circle cx="57" cy="35" r="16" fill="#FFC8DD" />
        <circle cx="50" cy="42" r="14" fill="#FF85A1" />
        <circle cx="50" cy="34" r="10" fill="#FFE5EC" />
        <circle cx="50" cy="34" r="5" fill="#FFD166" />
      </svg>
    );
  }

  if (type === 'daisy') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path d="M50 50 Q49 75 50 95" stroke="#606C38" strokeWidth="3.5" strokeLinecap="round" />
        {/* Daisy White Petals */}
        {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
          <ellipse
            key={deg}
            cx="50"
            cy="20"
            rx="5"
            ry="14"
            fill="#FFFFFF"
            stroke="#FFE4E6"
            strokeWidth="0.8"
            transform={`rotate(${deg} 50 40)`}
          />
        ))}
        <circle cx="50" cy="40" r="10" fill="#FFD166" />
        <circle cx="50" cy="40" r="8" fill="#F4A261" opacity="0.6" />
        <circle cx="48" cy="38" r="2" fill="#FFF" />
      </svg>
    );
  }

  if (type === 'sunflower') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path d="M50 50 Q52 75 50 95" stroke="#386641" strokeWidth="4" strokeLinecap="round" />
        {[0, 22.5, 45, 67.5, 90, 112.5, 135, 157.5, 180, 202.5, 225, 247.5, 270, 292.5, 315, 337.5].map((deg) => (
          <ellipse
            key={deg}
            cx="50"
            cy="18"
            rx="5.5"
            ry="16"
            fill="#FFB703"
            transform={`rotate(${deg} 50 40)`}
          />
        ))}
        <circle cx="50" cy="40" r="12" fill="#6B4226" />
        <circle cx="50" cy="40" r="9" fill="#43281C" />
        <circle cx="47" cy="37" r="2" fill="#FFD166" opacity="0.6" />
      </svg>
    );
  }

  if (type === 'babysbreath') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path d="M50 95 L50 60" stroke="#74A892" strokeWidth="2.5" />
        <path d="M50 60 L30 40 M50 60 L70 38 M50 45 L50 25 M40 50 L25 58 M60 48 L75 55" stroke="#74A892" strokeWidth="1.5" />
        {/* Tiny Starry Flower puffs */}
        {[
          { x: 30, y: 40, r: 6 },
          { x: 70, y: 38, r: 6 },
          { x: 50, y: 25, r: 7 },
          { x: 25, y: 58, r: 5 },
          { x: 75, y: 55, r: 5 },
          { x: 40, y: 35, r: 5 },
          { x: 62, y: 32, r: 5 },
        ].map((pt, i) => (
          <g key={i}>
            <circle cx={pt.x} cy={pt.y} r={pt.r} fill="#FFFFFF" stroke="#E2D4F0" strokeWidth="0.8" />
            <circle cx={pt.x} cy={pt.y} r={pt.r * 0.4} fill="#CDB4DB" />
          </g>
        ))}
      </svg>
    );
  }

  if (type === 'strawberry') {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        <path d="M50 50 Q50 75 50 95" stroke="#52B788" strokeWidth="3" strokeLinecap="round" />
        {/* Leaves */}
        <path d="M50 26 C40 20 30 22 25 24 C35 28 45 28 50 26Z" fill="#2D6A4F" />
        <path d="M50 26 C60 20 70 22 75 24 C65 28 55 28 50 26Z" fill="#2D6A4F" />
        <path d="M50 26 C46 16 54 16 50 26Z" fill="#40916C" />
        {/* Strawberry Body */}
        <path
          d="M32 30 C30 50 42 62 50 65 C58 62 70 50 68 30 C60 26 40 26 32 30Z"
          fill="#FF3366"
        />
        {/* Seeds */}
        {[
          { x: 42, y: 36 },
          { x: 58, y: 36 },
          { x: 50, y: 44 },
          { x: 40, y: 50 },
          { x: 60, y: 50 },
          { x: 50, y: 56 },
        ].map((s, i) => (
          <ellipse key={i} cx={s.x} cy={s.y} rx="1.2" ry="2" fill="#FFD166" />
        ))}
        {/* White mini flower */}
        <circle cx="68" cy="24" r="5" fill="#FFF" />
        <circle cx="68" cy="24" r="2" fill="#FFD166" />
      </svg>
    );
  }

  // Hello Kitty Bow Bloom
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path d="M50 55 Q50 78 50 95" stroke="#70B77E" strokeWidth="4" strokeLinecap="round" />
      {/* Hello Kitty Red Ribbon Bow */}
      {/* Left Bow Loop */}
      <path
        d="M50 36 C42 22 22 20 20 34 C18 46 38 48 50 38Z"
        fill="#FF2E63"
        stroke="#D90429"
        strokeWidth="2.5"
      />
      <ellipse cx="28" cy="32" rx="4" ry="7" fill="#FF758F" opacity="0.6" transform="rotate(-20 28 32)" />
      {/* Right Bow Loop */}
      <path
        d="M50 36 C58 22 78 20 80 34 C82 46 62 48 50 38Z"
        fill="#FF2E63"
        stroke="#D90429"
        strokeWidth="2.5"
      />
      <ellipse cx="72" cy="32" rx="4" ry="7" fill="#FF758F" opacity="0.6" transform="rotate(20 72 32)" />
      {/* Center Bow Knot */}
      <circle cx="50" cy="36" r="8.5" fill="#FF0054" stroke="#D90429" strokeWidth="2.5" />
      <circle cx="48" cy="34" r="2.5" fill="#FFF" opacity="0.7" />
      {/* Cute Kitty Whiskers / Ears accent */}
      <path d="M38 18 L43 25" stroke="#2B2D42" strokeWidth="2.5" strokeLinecap="round" />
      <path d="M62 18 L57 25" stroke="#2B2D42" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
};
