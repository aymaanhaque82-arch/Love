import React from 'react';

interface HelloKittyIconProps {
  size?: number;
  className?: string;
  expression?: 'happy' | 'wink' | 'love' | 'blush';
}

export const HelloKittyIcon: React.FC<HelloKittyIconProps> = ({
  size = 48,
  className = '',
  expression = 'happy',
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none ${className}`}
    >
      {/* Hello Kitty Head (Classic Soft Oval with Ears) */}
      <g>
        {/* Left Ear */}
        <path
          d="M26 46 C20 30 24 16 38 20 C42 22 46 26 50 32"
          fill="#FFFFFF"
          stroke="#2A2A2A"
          strokeWidth="4"
          strokeLinejoin="round"
        />
        {/* Right Ear */}
        <path
          d="M94 46 C100 30 96 16 82 20 C78 22 74 26 70 32"
          fill="#FFFFFF"
          stroke="#2A2A2A"
          strokeWidth="4"
          strokeLinejoin="round"
        />
        {/* Head Base */}
        <ellipse
          cx="60"
          cy="64"
          rx="44"
          ry="36"
          fill="#FFFFFF"
          stroke="#2A2A2A"
          strokeWidth="4"
        />
      </g>

      {/* Signature Red Bow on Left Ear */}
      <g>
        {/* Left loop */}
        <ellipse
          cx="28"
          cy="26"
          rx="12"
          ry="9"
          fill="#FF2A55"
          stroke="#2A2A2A"
          strokeWidth="3.5"
          transform="rotate(-15 28 26)"
        />
        <circle cx="27" cy="24" r="3" fill="#FF85A2" />
        {/* Right loop */}
        <ellipse
          cx="48"
          cy="30"
          rx="12"
          ry="9"
          fill="#FF2A55"
          stroke="#2A2A2A"
          strokeWidth="3.5"
          transform="rotate(25 48 30)"
        />
        <circle cx="49" cy="28" r="3" fill="#FF85A2" />
        {/* Center knot */}
        <circle
          cx="38"
          cy="29"
          r="7.5"
          fill="#FF1443"
          stroke="#2A2A2A"
          strokeWidth="3.5"
        />
        <circle cx="36" cy="27" r="2" fill="#FFFFFF" opacity="0.8" />
      </g>

      {/* Cute Whiskers */}
      <g stroke="#2A2A2A" strokeWidth="3.5" strokeLinecap="round">
        {/* Left Whiskers */}
        <line x1="20" y1="58" x2="6" y2="55" />
        <line x1="18" y1="66" x2="4" y2="67" />
        <line x1="20" y1="74" x2="7" y2="79" />

        {/* Right Whiskers */}
        <line x1="100" y1="58" x2="114" y2="55" />
        <line x1="102" y1="66" x2="116" y2="67" />
        <line x1="100" y1="74" x2="113" y2="79" />
      </g>

      {/* Eyes based on expression */}
      {expression === 'wink' ? (
        <g>
          {/* Left Eye: wink arc */}
          <path
            d="M40 68 Q46 62 50 68"
            stroke="#2A2A2A"
            strokeWidth="4"
            strokeLinecap="round"
            fill="none"
          />
          {/* Right Eye: normal oval */}
          <ellipse cx="74" cy="65" rx="4.5" ry="6.5" fill="#2A2A2A" />
        </g>
      ) : expression === 'love' ? (
        <g fill="#FF2A55">
          {/* Left Heart Eye */}
          <path d="M44 60 C40 56 36 58 36 62 C36 68 44 73 44 73 C44 73 52 68 52 62 C52 58 48 56 44 60Z" />
          {/* Right Heart Eye */}
          <path d="M76 60 C72 56 68 58 68 62 C68 68 76 73 76 73 C76 73 84 68 84 62 C84 58 80 56 76 60Z" />
        </g>
      ) : (
        <g fill="#2A2A2A">
          <ellipse cx="45" cy="65" rx="4.5" ry="6.5" />
          <ellipse cx="75" cy="65" rx="4.5" ry="6.5" />
        </g>
      )}

      {/* Cute Blush Cheeks */}
      <ellipse cx="36" cy="74" rx="7" ry="4" fill="#FFAEC0" opacity="0.75" />
      <ellipse cx="84" cy="74" rx="7" ry="4" fill="#FFAEC0" opacity="0.75" />

      {/* Signature Yellow Button Nose */}
      <ellipse
        cx="60"
        cy="72"
        rx="5.5"
        ry="4"
        fill="#FFD100"
        stroke="#2A2A2A"
        strokeWidth="2.5"
      />
    </svg>
  );
};
