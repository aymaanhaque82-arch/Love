import React, { useEffect, useState } from 'react';
import { Heart, Volume2, VolumeX, Music, Settings, Sparkles, Flower2, Mail, Camera, Stars } from 'lucide-react';
import { HelloKittyIcon } from './HelloKittyIcon';
import { CoupleProfile } from '../types';
import { playSound } from '../utils/audio';

interface NavbarProps {
  activeTab: 'admiration' | 'bouquet' | 'notes' | 'gallery';
  setActiveTab: (tab: 'admiration' | 'bouquet' | 'notes' | 'gallery') => void;
  profile: CoupleProfile;
  onOpenSettings: () => void;
  onToggleSound: () => void;
  onToggleMusic: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  profile,
  onOpenSettings,
  onToggleSound,
  onToggleMusic,
}) => {
  const [daysCount, setDaysCount] = useState<number>(0);
  const [kittyExpression, setKittyExpression] = useState<'happy' | 'wink' | 'love'>('happy');

  useEffect(() => {
    try {
      const start = new Date(profile.relationshipStartDate).getTime();
      const now = new Date().getTime();
      const diff = Math.max(0, Math.floor((now - start) / (1000 * 60 * 60 * 24)));
      setDaysCount(diff);
    } catch {
      setDaysCount(100);
    }
  }, [profile.relationshipStartDate]);

  const handleKittyClick = () => {
    playSound('pop', profile.soundEnabled);
    setKittyExpression((prev) => (prev === 'happy' ? 'love' : prev === 'love' ? 'wink' : 'happy'));
  };

  const handleTabClick = (tab: 'admiration' | 'bouquet' | 'notes' | 'gallery') => {
    playSound('chime', profile.soundEnabled);
    setActiveTab(tab);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/85 backdrop-blur-md border-b-2 border-pink-200/80 shadow-xs">
      {/* Top Cute Ribbon Banner */}
      <div className="bg-linear-to-r from-pink-400 via-rose-400 to-pink-400 text-white text-xs py-1 px-4 text-center font-medium flex items-center justify-center gap-2 shadow-xs">
        <Sparkles className="w-3.5 h-3.5 animate-sparkle" />
        <span>A sweet sanctuary for <strong className="underline decoration-pink-200">{profile.herName}</strong> — Loved endlessly by {profile.hisName} 🎀</span>
        <Sparkles className="w-3.5 h-3.5 animate-sparkle" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18 sm:h-20">
          {/* Logo & Hello Kitty Avatar */}
          <div className="flex items-center gap-3">
            <button
              id="hello-kitty-header-avatar"
              onClick={handleKittyClick}
              className="relative p-1 rounded-2xl transition-transform hover:scale-105 active:scale-95 cursor-pointer group"
              title="Click Hello Kitty for cute reaction!"
            >
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-pink-100 border-2 border-pink-300 flex items-center justify-center shadow-inner group-hover:border-pink-400">
                <HelloKittyIcon size={46} expression={kittyExpression} />
              </div>
              <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-rose-500 border border-white items-center justify-center text-[9px] text-white">🎀</span>
              </span>
            </button>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-bold font-cute tracking-tight text-pink-900 flex items-center gap-1.5">
                  <span>Forever Ours</span>
                  <span className="text-rose-500 animate-heartbeat inline-block">💖</span>
                </h1>
              </div>
              <p className="text-xs font-handwriting text-pink-700 sm:text-sm font-semibold">
                {profile.hisName} & {profile.herNickname || profile.herName}
              </p>
            </div>
          </div>

          {/* Center Days of Love Badge */}
          <div className="hidden md:flex items-center gap-2 px-4 py-1.5 rounded-full bg-pink-50 border-2 border-pink-200 text-pink-800 shadow-xs">
            <Heart className="w-4 h-4 text-rose-500 fill-rose-500 animate-pulse" />
            <span className="text-xs font-semibold">
              Loving You For <strong className="text-rose-600 font-bold text-sm">{daysCount}</strong> Days & Forever
            </span>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* Ambient Music Toggle */}
            <button
              id="ambient-music-toggle"
              onClick={onToggleMusic}
              className={`p-2 rounded-full border transition-all cursor-pointer ${
                profile.ambientMusicPlaying
                  ? 'bg-rose-500 text-white border-rose-600 shadow-sm animate-pulse'
                  : 'bg-pink-50 text-pink-700 border-pink-200 hover:bg-pink-100'
              }`}
              title={profile.ambientMusicPlaying ? 'Pause Lofi Music Box' : 'Play Gentle Love Lullaby'}
            >
              <Music className="w-4 h-4" />
            </button>

            {/* Sound FX Toggle */}
            <button
              id="sound-fx-toggle"
              onClick={onToggleSound}
              className={`p-2 rounded-full border transition-all cursor-pointer ${
                profile.soundEnabled
                  ? 'bg-pink-100 text-pink-700 border-pink-300 hover:bg-pink-200'
                  : 'bg-gray-100 text-gray-400 border-gray-200'
              }`}
              title={profile.soundEnabled ? 'Mute cute sounds' : 'Enable cute sounds'}
            >
              {profile.soundEnabled ? <Volume2 className="w-4 h-4 text-rose-500" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Settings */}
            <button
              id="couple-settings-btn"
              onClick={onOpenSettings}
              className="p-2 rounded-full bg-pink-50 text-pink-700 border border-pink-200 hover:bg-pink-100 transition-colors cursor-pointer"
              title="Personalize names & anniversary date"
            >
              <Settings className="w-4 h-4 text-pink-700" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Navigation Bar */}
        <nav className="flex items-center justify-center sm:justify-start gap-1 sm:gap-2 py-2 overflow-x-auto no-scrollbar border-t border-pink-100">
          <button
            id="nav-tab-admiration"
            onClick={() => handleTabClick('admiration')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'admiration'
                ? 'bg-rose-500 text-white shadow-xs scale-102'
                : 'text-pink-800 hover:bg-pink-100/70 hover:text-pink-900'
            }`}
          >
            <Stars className="w-4 h-4" />
            <span>Why I Adore You</span>
          </button>

          <button
            id="nav-tab-bouquet"
            onClick={() => handleTabClick('bouquet')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'bouquet'
                ? 'bg-rose-500 text-white shadow-xs scale-102'
                : 'text-pink-800 hover:bg-pink-100/70 hover:text-pink-900'
            }`}
          >
            <Flower2 className="w-4 h-4" />
            <span>Digital Bouquet</span>
          </button>

          <button
            id="nav-tab-notes"
            onClick={() => handleTabClick('notes')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'notes'
                ? 'bg-rose-500 text-white shadow-xs scale-102'
                : 'text-pink-800 hover:bg-pink-100/70 hover:text-pink-900'
            }`}
          >
            <Mail className="w-4 h-4" />
            <span>Daily Notes & Letters</span>
          </button>

          <button
            id="nav-tab-gallery"
            onClick={() => handleTabClick('gallery')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'gallery'
                ? 'bg-rose-500 text-white shadow-xs scale-102'
                : 'text-pink-800 hover:bg-pink-100/70 hover:text-pink-900'
            }`}
          >
            <Camera className="w-4 h-4" />
            <span>Photo Memories</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
