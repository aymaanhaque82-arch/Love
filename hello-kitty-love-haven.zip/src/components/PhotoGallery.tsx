import React, { useState } from 'react';
import { Camera, Plus, Heart, Sparkles, MapPin, Calendar, RotateCw, Image as ImageIcon, Trash2, Eye, Filter } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CoupleProfile, MemoryPhoto } from '../types';
import { HelloKittyIcon } from './HelloKittyIcon';
import { playSound } from '../utils/audio';

interface PhotoGalleryProps {
  profile: CoupleProfile;
  memories: MemoryPhoto[];
  onAddMemory: (memory: MemoryPhoto) => void;
  onDeleteMemory: (id: string) => void;
  onToggleFavorite: (id: string) => void;
}

export const PhotoGallery: React.FC<PhotoGalleryProps> = ({
  profile,
  memories,
  onAddMemory,
  onDeleteMemory,
  onToggleFavorite,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [flippedCardId, setFlippedCardId] = useState<string | null>(null);
  const [lightboxPhoto, setLightboxPhoto] = useState<MemoryPhoto | null>(null);
  const [isAddingPhoto, setIsAddingPhoto] = useState<boolean>(false);

  // New photo form state
  const [newTitle, setNewTitle] = useState<string>('');
  const [newDate, setNewDate] = useState<string>('');
  const [newLocation, setNewLocation] = useState<string>('');
  const [newImageUrl, setNewImageUrl] = useState<string>('');
  const [newCaption, setNewCaption] = useState<string>('');
  const [newBackNote, setNewBackNote] = useState<string>('');
  const [newCategory, setNewCategory] = useState<MemoryPhoto['category']>('dates');

  const filteredMemories = memories.filter((m) =>
    selectedCategory === 'all' ? true : m.category === selectedCategory
  );

  const handleFlipCard = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    playSound('pop', profile.soundEnabled);
    setFlippedCardId((prev) => (prev === id ? null : id));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      if (typeof reader.result === 'string') {
        setNewImageUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAddMemorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newImageUrl.trim()) {
      alert('Please provide a title and photo image!');
      return;
    }

    playSound('sparkle', profile.soundEnabled);

    const newMem: MemoryPhoto = {
      id: `mem-${Date.now()}`,
      title: newTitle.trim(),
      date: newDate.trim() || new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
      location: newLocation.trim() || 'Together With You',
      imageUrl: newImageUrl,
      caption: newCaption.trim() || 'A cherished moment forever saved.',
      backNote: newBackNote.trim() || 'Every second with you is a treasure I hold close to my heart.',
      category: newCategory,
      isFavorite: false,
      stickers: ['🎀', '💖', '✨'],
    };

    onAddMemory(newMem);
    setIsAddingPhoto(false);
    setNewTitle('');
    setNewDate('');
    setNewLocation('');
    setNewImageUrl('');
    setNewCaption('');
    setNewBackNote('');

    confetti({
      particleCount: 30,
      spread: 60,
      origin: { y: 0.6 },
      colors: ['#FF2A55', '#FF70A6', '#FFD166'],
    });
  };

  return (
    <div className="space-y-8">
      {/* Gallery Header */}
      <div className="bg-white rounded-3xl border-2 border-pink-200 p-6 sm:p-8 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-100 border border-pink-300 flex items-center justify-center text-2xl shadow-xs">
            📸
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold font-cute text-pink-950">
              Our Cherished Photo Memories
            </h2>
            <p className="text-xs sm:text-sm text-pink-700 font-medium">
              Polaroid moments with secret love stories written on the back of every card.
            </p>
          </div>
        </div>

        <button
          id="add-memory-photo-btn"
          onClick={() => {
            setIsAddingPhoto(true);
            playSound('pop', profile.soundEnabled);
          }}
          className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-rose-500 hover:bg-rose-600 active:scale-95 text-white font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Memory 🎀</span>
        </button>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
        {[
          { id: 'all', label: 'All Moments', icon: '✨' },
          { id: 'dates', label: 'Dates & Dinners', icon: '🍰' },
          { id: 'cozy', label: 'Cozy Days', icon: '🧸' },
          { id: 'trips', label: 'Trips & Walks', icon: '🌸' },
          { id: 'milestones', label: 'Special Milestones', icon: '💍' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              setSelectedCategory(cat.id);
              playSound('pop', profile.soundEnabled);
            }}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-2xl text-xs sm:text-sm font-bold transition-all cursor-pointer whitespace-nowrap ${
              selectedCategory === cat.id
                ? 'bg-rose-500 text-white shadow-xs scale-102'
                : 'bg-white text-pink-800 border border-pink-200 hover:bg-pink-50'
            }`}
          >
            <span>{cat.icon}</span>
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Polaroid Gallery Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredMemories.map((mem) => {
          const isFlipped = flippedCardId === mem.id;

          return (
            <div
              key={mem.id}
              className="relative perspective-1000 group"
            >
              {/* Top Washi Tape */}
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-20 w-24 h-6 bg-pink-200/90 border border-pink-300 rounded-xs shadow-2xs rotate-[-1deg] select-none flex items-center justify-center">
                <span className="text-[10px] text-pink-700 font-cute font-bold">Forever 🎀</span>
              </div>

              {/* Polaroid Frame Card with 3D Flip */}
              <div
                className={`relative w-full rounded-3xl bg-white border-4 border-pink-200/90 p-4 pb-6 shadow-md hover:shadow-xl transition-all duration-500 transform-style-3d ${
                  isFlipped ? 'rotate-y-180 bg-[#FFFDF8]' : ''
                }`}
              >
                {!isFlipped ? (
                  /* Front Side: Photo & Caption */
                  <div className="space-y-3">
                    {/* Photo Container */}
                    <div className="relative aspect-4/3 w-full rounded-2xl overflow-hidden bg-pink-50 border border-pink-200">
                      <img
                        src={mem.imageUrl}
                        alt={mem.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />

                      {/* Favorite Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(mem.id);
                          playSound('heart', profile.soundEnabled);
                        }}
                        className={`absolute top-2 right-2 p-2 rounded-full backdrop-blur-xs transition-transform hover:scale-110 cursor-pointer ${
                          mem.isFavorite
                            ? 'bg-rose-500 text-white shadow-xs'
                            : 'bg-white/80 text-pink-400 hover:text-rose-500'
                        }`}
                        title="Favorite this memory"
                      >
                        <Heart className="w-4 h-4 fill-current" />
                      </button>

                      {/* Corner Cute Stickers */}
                      <div className="absolute bottom-2 left-2 flex items-center gap-1">
                        {mem.stickers?.map((s, i) => (
                          <span
                            key={i}
                            className="text-sm bg-white/90 p-1 rounded-full shadow-2xs"
                          >
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Metadata & Handwritten Caption */}
                    <div className="space-y-1.5 pt-1">
                      <div className="flex items-center justify-between text-[11px] text-pink-600 font-semibold">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-pink-400" />
                          {mem.date}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-pink-400" />
                          {mem.location}
                        </span>
                      </div>

                      <h4 className="font-bold font-cute text-base text-pink-950">
                        {mem.title}
                      </h4>

                      <p className="text-pink-900 font-handwriting text-lg leading-snug">
                        "{mem.caption}"
                      </p>
                    </div>

                    {/* Bottom Card Controls */}
                    <div className="pt-3 border-t border-pink-100 flex items-center justify-between">
                      <button
                        onClick={(e) => handleFlipCard(mem.id, e)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-pink-100 hover:bg-pink-200 text-pink-800 font-bold text-xs cursor-pointer"
                        title="Read secret note on back"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                        <span>Read Back Note</span>
                      </button>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setLightboxPhoto(mem)}
                          className="p-1.5 rounded-lg text-pink-400 hover:text-pink-800 hover:bg-pink-50 cursor-pointer"
                          title="View fullscreen"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => {
                            if (confirm('Delete this memory?')) {
                              onDeleteMemory(mem.id);
                              playSound('pop', profile.soundEnabled);
                            }
                          }}
                          className="p-1.5 rounded-lg text-pink-400 hover:text-red-500 hover:bg-pink-50 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Back Side: Secret Love Story */
                  <div className="min-h-[300px] flex flex-col justify-between p-2 space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center justify-between border-b border-pink-200 pb-2">
                        <span className="text-xs font-bold text-rose-500 uppercase tracking-wider flex items-center gap-1">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>Secret Memory Journal</span>
                        </span>
                        <button
                          onClick={(e) => handleFlipCard(mem.id, e)}
                          className="text-xs text-pink-600 hover:text-pink-900 font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCw className="w-3 h-3" />
                          <span>Flip to Photo</span>
                        </button>
                      </div>

                      <h4 className="font-bold font-cute text-sm text-pink-950">
                        {mem.title}
                      </h4>

                      <p className="text-pink-900 font-handwriting text-xl sm:text-2xl leading-relaxed whitespace-pre-wrap">
                        "{mem.backNote}"
                      </p>
                    </div>

                    <div className="pt-3 border-t border-pink-200/60 flex items-center justify-between text-xs text-pink-700 font-semibold font-handwriting text-base">
                      <span>Saved in my heart forever</span>
                      <span>— {profile.hisName} 🎀</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add New Memory Modal */}
      {isAddingPhoto && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="relative w-full max-w-lg bg-white rounded-3xl border-4 border-pink-300 shadow-2xl p-6 sm:p-8 max-h-[90vh] overflow-y-auto space-y-5">
            <div className="flex items-center justify-between border-b border-pink-100 pb-3">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-rose-500" />
                <h3 className="text-xl font-bold font-cute text-pink-950">
                  Add A Cherished Memory 📸
                </h3>
              </div>
              <button
                onClick={() => setIsAddingPhoto(false)}
                className="w-8 h-8 rounded-full bg-pink-100 text-pink-800 font-bold hover:bg-pink-200 flex items-center justify-center cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddMemorySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-pink-800 mb-1">Memory Title:</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Our First Seaside Walk 🌊"
                  className="w-full px-4 py-2 rounded-xl bg-pink-50 border border-pink-200 text-sm font-cute text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                  required
                />
              </div>

              {/* Photo Input (Upload File or URL) */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-pink-800">Photo Image:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="block w-full text-xs text-pink-700 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-pink-100 file:text-pink-800 hover:file:bg-pink-200 cursor-pointer"
                  />
                </div>

                <div className="text-center text-xs text-pink-400 font-semibold">— OR enter image link —</div>

                <input
                  type="url"
                  value={newImageUrl}
                  onChange={(e) => setNewImageUrl(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full px-4 py-2 rounded-xl bg-pink-50 border border-pink-200 text-xs font-cute text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                />

                {newImageUrl && (
                  <div className="w-full h-32 rounded-xl overflow-hidden border border-pink-300 mt-2">
                    <img src={newImageUrl} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-pink-800 mb-1">Date:</label>
                  <input
                    type="text"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    placeholder="e.g. October 14, 2025"
                    className="w-full px-3 py-2 rounded-xl bg-pink-50 border border-pink-200 text-xs text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-pink-800 mb-1">Location:</label>
                  <input
                    type="text"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    placeholder="e.g. Blossom Cafe"
                    className="w-full px-3 py-2 rounded-xl bg-pink-50 border border-pink-200 text-xs text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-pink-800 mb-1">Category:</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as MemoryPhoto['category'])}
                  className="w-full px-3 py-2 rounded-xl bg-pink-50 border border-pink-200 text-xs font-bold text-pink-900 focus:outline-none focus:ring-2 focus:ring-rose-400"
                >
                  <option value="dates">Dates & Outings</option>
                  <option value="cozy">Cozy Moments</option>
                  <option value="trips">Trips & Walks</option>
                  <option value="milestones">Special Milestones</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-pink-800 mb-1">Front Caption:</label>
                <input
                  type="text"
                  value={newCaption}
                  onChange={(e) => setNewCaption(e.target.value)}
                  placeholder="e.g. Smiling together under the sunset 🌅"
                  className="w-full px-4 py-2 rounded-xl bg-pink-50 border border-pink-200 text-xs text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-pink-800 mb-1">
                  Secret Note on Back of Photo:
                </label>
                <textarea
                  rows={3}
                  value={newBackNote}
                  onChange={(e) => setNewBackNote(e.target.value)}
                  placeholder="Write the intimate secret story or feeling from that day..."
                  className="w-full p-3 rounded-xl bg-[#FFFDF9] border border-pink-200 font-handwriting text-lg text-pink-950 focus:outline-none focus:ring-2 focus:ring-rose-400"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddingPhoto(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-pink-700 hover:bg-pink-50 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <span>Save Memory Forever 💖</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Fullscreen Lightbox Modal */}
      {lightboxPhoto && (
        <div
          onClick={() => setLightboxPhoto(null)}
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in cursor-pointer"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-3xl w-full bg-white rounded-3xl p-4 sm:p-6 shadow-2xl border-4 border-pink-300 space-y-4"
          >
            <div className="relative aspect-16/10 rounded-2xl overflow-hidden bg-black">
              <img
                src={lightboxPhoto.imageUrl}
                alt={lightboxPhoto.title}
                className="w-full h-full object-contain"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold font-cute text-pink-950">
                  {lightboxPhoto.title}
                </h3>
                <span className="text-xs font-semibold text-pink-600">
                  {lightboxPhoto.date} • {lightboxPhoto.location}
                </span>
              </div>
              <p className="text-pink-900 font-handwriting text-2xl">
                "{lightboxPhoto.caption}"
              </p>
            </div>

            <div className="text-right">
              <button
                onClick={() => setLightboxPhoto(null)}
                className="px-5 py-2 rounded-xl bg-rose-500 text-white font-bold text-xs cursor-pointer hover:bg-rose-600"
              >
                Close ✕
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
