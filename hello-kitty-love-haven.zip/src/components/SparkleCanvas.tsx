import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  opacity: number;
  maxOpacity: number;
  color: string;
  type: 'sparkle' | 'heart' | 'star' | 'circle';
  rotation: number;
  rotationSpeed: number;
}

export const SparkleCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseTrailRef = useRef<{ x: number; y: number; age: number; color: string }[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const colors = [
      'rgba(255, 182, 193, ', // Pastel pink
      'rgba(255, 105, 180, ', // Hot pink
      'rgba(255, 218, 185, ', // Peach
      'rgba(230, 190, 255, ', // Lilac
      'rgba(255, 240, 180, ', // Soft yellow star
      'rgba(255, 190, 210, ', // Blush
    ];

    // Initialize floating ambient particles
    const particleCount = Math.min(40, Math.floor((width * height) / 35000));
    particlesRef.current = [];

    for (let i = 0; i < particleCount; i++) {
      particlesRef.current.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 5 + 3,
        speedX: (Math.random() - 0.5) * 0.4,
        speedY: -Math.random() * 0.5 - 0.2, // Drift softly upward
        opacity: Math.random() * 0.5 + 0.2,
        maxOpacity: Math.random() * 0.6 + 0.3,
        color: colors[Math.floor(Math.random() * colors.length)],
        type: (['sparkle', 'heart', 'star', 'circle'] as const)[Math.floor(Math.random() * 4)],
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 1.5,
      });
    }

    const handleMouseMove = (e: MouseEvent) => {
      // Add cursor sparkle trail
      const trailColor = colors[Math.floor(Math.random() * colors.length)];
      mouseTrailRef.current.push({
        x: e.clientX,
        y: e.clientY,
        age: 0,
        color: trailColor,
      });

      if (mouseTrailRef.current.length > 25) {
        mouseTrailRef.current.shift();
      }
    };

    window.addEventListener('mousemove', handleMouseMove);

    const drawHeart = (c: CanvasRenderingContext2D, x: number, y: number, size: number) => {
      c.beginPath();
      const topCurveHeight = size * 0.3;
      c.moveTo(x, y + topCurveHeight);
      c.bezierCurveTo(x, y, x - size / 2, y, x - size / 2, y + topCurveHeight);
      c.bezierCurveTo(x - size / 2, y + (size + topCurveHeight) / 2, x, y + size, x, y + size);
      c.bezierCurveTo(x, y + size, x + size / 2, y + (size + topCurveHeight) / 2, x + size / 2, y + topCurveHeight);
      c.bezierCurveTo(x + size / 2, y, x, y, x, y + topCurveHeight);
      c.closePath();
      c.fill();
    };

    const drawStar = (c: CanvasRenderingContext2D, x: number, y: number, spikes: number, outerRadius: number, innerRadius: number) => {
      let rot = (Math.PI / 2) * 3;
      let cx = x;
      let cy = y;
      const step = Math.PI / spikes;

      c.beginPath();
      c.moveTo(cx, cy - outerRadius);
      for (let i = 0; i < spikes; i++) {
        cx = x + Math.cos(rot) * outerRadius;
        cy = y + Math.sin(rot) * outerRadius;
        c.lineTo(cx, cy);
        rot += step;

        cx = x + Math.cos(rot) * innerRadius;
        cy = y + Math.sin(rot) * innerRadius;
        c.lineTo(cx, cy);
        rot += step;
      }
      c.lineTo(x, y - outerRadius);
      c.closePath();
      c.fill();
    };

    const drawSparkle = (c: CanvasRenderingContext2D, x: number, y: number, size: number) => {
      drawStar(c, x, y, 4, size, size * 0.3);
    };

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw cursor sparkle trail
      for (let i = mouseTrailRef.current.length - 1; i >= 0; i--) {
        const pt = mouseTrailRef.current[i];
        pt.age += 1;
        const life = 1 - pt.age / 24;
        if (life <= 0) {
          mouseTrailRef.current.splice(i, 1);
          continue;
        }

        ctx.save();
        ctx.fillStyle = `${pt.color}${life * 0.7})`;
        ctx.shadowColor = 'rgba(255, 182, 193, 0.8)';
        ctx.shadowBlur = 8;
        drawSparkle(ctx, pt.x, pt.y, (1 - life * 0.2) * 7);
        ctx.restore();
      }

      // Draw ambient floating sparkles & hearts
      particlesRef.current.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        p.rotation += p.rotationSpeed;

        if (p.y < -20) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < -20) p.x = width + 10;
        if (p.x > width + 20) p.x = -10;

        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = `${p.color}${p.opacity})`;

        if (p.type === 'sparkle') {
          drawSparkle(ctx, 0, 0, p.size);
        } else if (p.type === 'heart') {
          drawHeart(ctx, 0, -p.size / 2, p.size);
        } else if (p.type === 'star') {
          drawStar(ctx, 0, 0, 5, p.size, p.size * 0.45);
        } else {
          ctx.beginPath();
          ctx.arc(0, 0, p.size * 0.5, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      id="sparkle-ambient-canvas"
      className="fixed inset-0 pointer-events-none z-0"
    />
  );
};
